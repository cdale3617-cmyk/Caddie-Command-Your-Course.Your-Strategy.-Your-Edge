package com.drc.caddiecommand;
import android.app.*;import android.os.*;import android.graphics.Color;import android.view.*;import android.widget.*;
public class MainActivity extends Activity {
 LinearLayout root; int hole=1; boolean glare=false;
 int bg=0xff101820,gold=0xffd7b66d;
 TextView label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(glare?Color.BLACK:Color.WHITE);t.setTextSize(size);t.setPadding(20,15,20,15);return t;}
 void button(String s,Runnable action){Button b=new Button(this);b.setText(s);b.setOnClickListener(v->action.run());root.addView(b);}
 public void onCreate(Bundle b){super.onCreate(b);home();}
 void base(String title){ScrollView scroll=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(14,20,14,20);root.setBackgroundColor(glare?0xfff5f3e9:bg);scroll.addView(root);setContentView(scroll);TextView h=label(title,27);h.setTextColor(glare?0xff101820:gold);root.addView(h);}
 void home(){base("CADDIE COMMAND");root.addView(label("YOUR COURSE. YOUR STRATEGY. YOUR EDGE.",16));button("ENTER",()->live());button("MY BAG",()->bag());button("PRE-ROUND CHECKLIST",()->check());button("ANTI-GLARE: "+(glare?"ON":"OFF"),()->{glare=!glare;home();});}
 void live(){base("HOLE "+hole+" / 18");root.addView(label("GPS distance requires a selected course and surveyed hole coordinates.",16));root.addView(label("SAFE ROUTE  •  YELLOW\nAGGRESSIVE ROUTE  •  RED",20));root.addView(label("Wind and weather: live data not connected",16));button("PREVIOUS HOLE",()->{hole=Math.max(1,hole-1);live();});button("NEXT HOLE",()->{hole=Math.min(18,hole+1);live();});button("SCORECARD",()->score());button("GREEN READER (PROVISION)",()->{base("GREEN READER");root.addView(label("AR depth integration pending; no simulated readings.",18));button("BACK",()->live());});button("HOME",()->home());}
 void bag(){base("MY BAG");root.addView(label("Club distances: configuration pending",18));button("HOME",()->home());}
 void check(){base("PRE-ROUND CHECKLIST");for(String s:new String[]{"Clubs checked","Balls and tees","Water and sunscreen","Local rules","Weather checked"}){CheckBox c=new CheckBox(this);c.setText(s);c.setTextColor(glare?Color.BLACK:Color.WHITE);root.addView(c);}button("ENTER ROUND",()->live());}
 void score(){base("SCORECARD");for(int i=1;i<=18;i++){final int n=i;button("HOLE "+i+" — ENTER SCORE",()->{EditText e=new EditText(this);e.setInputType(2);new AlertDialog.Builder(this).setTitle("Hole "+n+" strokes").setView(e).setPositiveButton("SAVE",(d,w)->{getPreferences(0).edit().putString("score"+n,e.getText().toString()).apply();score();}).setNegativeButton("CANCEL",null).show();});String saved=getPreferences(0).getString("score"+i,"");if(!saved.isEmpty())root.addView(label("Saved: "+saved,14));}button("LIVE HOLE",()->live());}
}
