# Caddie Command — Android starter project

This is a functional **starter**, not the completed premium golf caddie. It includes a home screen, hole navigation, score entry and local saving, a pre-round checklist, anti-glare switch and reserved green-reader screen. Course maps, real GPS yardages, live weather/wind, course API, AR green scanning, and premium approved design are **not implemented**.

To build: upload the ZIP contents to a GitHub repository, then run the **Build Android APK** action. The workflow produces a debug APK artifact. Requires Android SDK and Gradle if building locally.
