package com.drc.caddiecommand;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;
import java.net.*;
import java.io.*;

public class MainActivity extends Activity {
 final int BG=Color.rgb(13,21,32), PANEL=Color.rgb(26,39,53), GOLD=Color.rgb(236,190,91), WHITE=Color.WHITE;
 LinearLayout body, root;
 TextView status;
 int hole=1, strokes=0;
 boolean contrast=false, yards=false;
 String course="My Course", weather="Weather: waiting for GPS", gps="GPS: waiting", target="";
 double lat=Double.NaN,lon=Double.NaN;
 android.content.SharedPreferences prefs;
 int[] pars=new int[19], lengths=new int[19];
 int[] scores=new int[19];
 @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("caddie",MODE_PRIVATE);
  course=prefs.getString("course","My Course");hole=prefs.getInt("hole",1);contrast=prefs.getBoolean("contrast",false);
  for(int i=1;i<=18;i++){pars[i]=prefs.getInt("par"+i,4);lengths[i]=prefs.getInt("len"+i,350);scores[i]=prefs.getInt("score"+i,0);}
  strokes=scores[hole];home();
 }
 int background(){return contrast?Color.BLACK:BG;} int panel(){return contrast?Color.rgb(22,22,22):PANEL;}
 GradientDrawable shape(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(20);d.setStroke(2,GOLD);return d;}
 TextView label(String text,int size,int color){TextView t=new TextView(this);t.setText(text);t.setTextSize(size);t.setTextColor(color);t.setPadding(18,14,18,14);return t;}
 void start(String title){
  root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(background());
  TextView header=label("CADDIE COMMAND  •  "+title,20,GOLD);header.setTypeface(null,Typeface.BOLD);root.addView(header);
  ScrollView sc=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(1);body.setPadding(14,8,14,22);sc.addView(body);
  root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
 }
 void card(String s){TextView t=label(s,18,WHITE);t.setBackground(shape(panel()));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,6,0,10);body.addView(t,p);}
 void button(String text,Runnable r){Button b=new Button(this);b.setAllCaps(false);b.setText(text);b.setTextSize(17);b.setTextColor(Color.BLACK);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GOLD));body.addView(b,new LinearLayout.LayoutParams(-1,-2));b.setOnClickListener(v->r.run());}
 void row(String a,Runnable ra,String b,Runnable rb){
  LinearLayout line=new LinearLayout(this);line.setOrientation(0);body.addView(line);
  for(int i=0;i<2;i++){Button bt=new Button(this);bt.setAllCaps(false);bt.setText(i==0?a:b);bt.setTextColor(Color.BLACK);
   bt.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GOLD));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);line.addView(bt,lp);
   final Runnable rr=i==0?ra:rb;bt.setOnClickListener(v->rr.run());}
 }
 void edit(String title,String initial,java.util.function.Consumer<String> done){
  EditText e=new EditText(this);e.setSingleLine(true);e.setText(initial);
  new AlertDialog.Builder(this).setTitle(title).setView(e).setNegativeButton("Cancel",null)
   .setPositiveButton("Save",(d,w)->done.accept(e.getText().toString().trim())).show();
 }
 void home(){start("HOME");card("YOUR COURSE. YOUR STRATEGY. YOUR EDGE.");
  card("Course: "+course+"\nHole "+hole+" / 18");
  button("ENTER CADDIE",()->live());
  button("CHANGE COURSE NAME",()->edit("Course name",course,s->{if(!s.isEmpty()){course=s;prefs.edit().putString("course",s).apply();home();}}));
  button("MY BAG",()->bag());button("SCORECARD",()->scorecard());
  button(contrast?"SUNLIGHT MODE: ON":"SUNLIGHT MODE: OFF",()->{contrast=!contrast;prefs.edit().putBoolean("contrast",contrast).apply();home();});
  card("Course diagrams are schematic. Real hole boundaries and pin locations require verified course data.");
 }
 void live(){start("LIVE HOLE");card(course+"   •   HOLE "+hole+"   •   PAR "+pars[hole]+"   •   "+lengths[hole]+(yards?" yd":" m"));
  card("TEE  ━━━━━  FAIRWAY  ━━━━━  GREEN\n\nSAFE ROUTE: YELLOW\nAGGRESSIVE ROUTE: RED\n\nIllustrative route only — not a surveyed course map.");
  card(gps+"\n"+weather+"\n"+target);
  row("GET GPS",()->getGps(),"SET TARGET",()->setTarget());
  row("SAFE PLAN",()->plan(false),"ATTACK PLAN",()->plan(true));
  button("PRE-SHOT CHECKLIST",()->checklist());
  row("− STROKE",()->{strokes=Math.max(0,strokes-1);save();live();},"+ STROKE",()->{strokes++;save();live();});
  card("Strokes this hole: "+strokes);
  row("PREVIOUS HOLE",()->move(-1),"NEXT HOLE",()->move(1));
  row("EDIT HOLE",()->editHole(),"SCORECARD",()->scorecard());
  row("HOME",()->home(),"METRES / YARDS",()->{yards=!yards;live();});
 }
 void save(){scores[hole]=strokes;prefs.edit().putInt("score"+hole,strokes).apply();}
 void move(int delta){save();hole=Math.max(1,Math.min(18,hole+delta));strokes=scores[hole];prefs.edit().putInt("hole",hole).apply();live();}
 void editHole(){LinearLayout box=new LinearLayout(this);box.setOrientation(1);
  EditText par=new EditText(this), len=new EditText(this);par.setInputType(2);len.setInputType(2);par.setHint("Par");len.setHint("Length in metres");
  par.setText(""+pars[hole]);len.setText(""+lengths[hole]);box.addView(par);box.addView(len);
  new AlertDialog.Builder(this).setTitle("Edit hole "+hole).setView(box).setNegativeButton("Cancel",null)
   .setPositiveButton("Save",(d,w)->{try{pars[hole]=Integer.parseInt(par.getText().toString());lengths[hole]=Integer.parseInt(len.getText().toString());
    prefs.edit().putInt("par"+hole,pars[hole]).putInt("len"+hole,lengths[hole]).apply();}catch(Exception ignored){}live();}).show();
 }
 void plan(boolean attack){new AlertDialog.Builder(this).setTitle(attack?"Aggressive route":"Safe route")
  .setMessage(attack?"Aim toward the green only when carry, hazards and wind allow. Verify distances before committing.":
   "Choose the widest landing area, avoid hazards and leave a comfortable approach distance. Verify distances before committing.")
  .setPositiveButton("OK",null).show();}
 void checklist(){new AlertDialog.Builder(this).setTitle("Shot checklist")
  .setMultiChoiceItems(new String[]{"Check target and hazards","Check wind and lie","Select club and landing area","Commit to shot","Record result"},null,(d,i,v)->{})
  .setPositiveButton("Done",null).show();}
 void scorecard(){start("SCORECARD");int total=0,par=0;for(int i=1;i<=18;i++){total+=scores[i];par+=pars[i];card("Hole "+i+"  •  Par "+pars[i]+"  •  Strokes "+(scores[i]==0?"—":scores[i]));}
  card("Total strokes: "+total+"  •  Course par: "+par);button("BACK TO HOLE",()->live());button("HOME",()->home());}
 void bag(){start("MY BAG");card("Club distances are personal estimates. Edit them in a future release.");
  String[] clubs={"Driver","3 Wood","5 Wood","4 Iron","5 Iron","6 Iron","7 Iron","8 Iron","9 Iron","Pitching Wedge","Gap Wedge","Sand Wedge","Lob Wedge","Putter"};
  int[] dist={210,190,175,160,150,140,130,120,110,95,80,65,45,0};
  for(int i=0;i<clubs.length;i++)card(clubs[i]+"   •   "+dist[i]+" m");
  button("HOME",()->home());}
 void setTarget(){edit("Target coordinates: latitude,longitude","",s->{try{String[] a=s.split(",");double tlat=Double.parseDouble(a[0].trim()),tlon=Double.parseDouble(a[1].trim());
   if(Double.isNaN(lat))target="Target saved. Get GPS for distance.";
   else{float[] result=new float[1];Location.distanceBetween(lat,lon,tlat,tlon,result);target="Target distance: "+Math.round(result[0])+" m";}
   prefs.edit().putString("targetCoords",s).apply();live();
  }catch(Exception e){Toast.makeText(this,"Enter latitude,longitude",Toast.LENGTH_LONG).show();}});}
 void getGps(){if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
   requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},100);return;}
  try{LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);
   Location l=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
   if(l==null)l=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
   if(l==null){gps="GPS: no recent fix. Go outdoors and retry.";live();return;}
   lat=l.getLatitude();lon=l.getLongitude();gps=String.format(java.util.Locale.US,"GPS: %.5f, %.5f",lat,lon);
   String coords=prefs.getString("targetCoords","");if(!coords.isEmpty()){try{String[] a=coords.split(",");float[] out=new float[1];
    Location.distanceBetween(lat,lon,Double.parseDouble(a[0]),Double.parseDouble(a[1]),out);target="Target distance: "+Math.round(out[0])+" m";}catch(Exception ignored){}}
   live();fetchWeather();
  }catch(Exception e){gps="GPS unavailable: "+e.getMessage();live();}
 }
 @Override public void onRequestPermissionsResult(int code,String[] p,int[] g){super.onRequestPermissionsResult(code,p,g);if(code==100&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)getGps();}
 void fetchWeather(){final double a=lat,b=lon;new Thread(()->{try{
   URL u=new URL("https://api.open-meteo.com/v1/forecast?latitude="+a+"&longitude="+b+"&current=temperature_2m,wind_speed_10m,wind_direction_10m&wind_speed_unit=kmh");
   HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(9000);c.setReadTimeout(9000);
   StringBuilder sb=new StringBuilder();try(BufferedReader rd=new BufferedReader(new InputStreamReader(c.getInputStream()))){String s;while((s=rd.readLine())!=null)sb.append(s);}
   JSONObject o=new JSONObject(sb.toString()).getJSONObject("current");
   weather="Weather: "+o.optDouble("temperature_2m")+"°C  •  Wind "+o.optDouble("wind_speed_10m")+" km/h from "+o.optInt("wind_direction_10m")+"°";
  }catch(Exception e){weather="Weather unavailable (check internet).";}runOnUiThread(()->live());}).start();}
 @Override public void onBackPressed(){home();}
}
