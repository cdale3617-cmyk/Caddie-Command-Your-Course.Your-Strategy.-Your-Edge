# Caddie Command
Standalone Android golf caddie starter app.

## Build
Upload the contents of this ZIP into the repository root and run **Actions → Build Android APK → Run workflow**.
The APK is available under the completed workflow's **Artifacts** section.

## Working
18-hole navigation; editable course name, hole par and length; GPS location and distance to a manually entered target; live weather from Open-Meteo when online and location allowed; safe/aggressive strategy cards; shot checklist; score +/- and local saved scores; club bag reference; sunlight contrast toggle.

## Limitations
This is a functional starter, not a verified finished product. Hole maps are schematic and do not contain real course geometry. Target coordinates must be supplied manually. Green reading, shot tracking, biometrics and global course search are NOT implemented. No API key is included. Weather needs network access.
